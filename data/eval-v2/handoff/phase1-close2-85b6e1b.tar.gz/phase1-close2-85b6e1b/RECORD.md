# 同一提交集中运行记录（commit 85b6e1b）

环境：Linux（Ubuntu 24.04 / Node v22.23.2），见 verification/environment.txt。

| 项 | 结果 | 明细 |
|---|---|---|
| 全量测试 | 通过 | 194 = 193 通过 + 1 跳过 + 0 失败 |
| 跳过（1） | 环境限制 | "回归：Windows junction 真正触达路径检查…"（非 Windows skip；其 Linux 等价能力由符号链接/别名用例覆盖） |
| 失败（0） | — | 无；无超时类失败 |
| scripted suite | 完成 | phase1-close2-85b6e1b：5 trial——3 行为 case 全绿；eng-version-drift/headfix 预期阻断（execution_error，trace 零取证事件） |
| replay | 一致 | 5/5 逐字段一致 |
| typecheck | 通过 | 0 错误 |
| docs:check | 通过 | tests.ts=194 |

新增反例（本提交覆盖）：单轮合法授权日志硬链接私有答案文件（运行期先证可读→预检 inode 阻断）；
泄漏比较 CRLF/多行/连续空格命中且不误报；不可读文件 incomplete_scan 不崩溃不判通过；
junction 夹具 errno 纪律（仅 EPERM/EACCES 可 skip）。
