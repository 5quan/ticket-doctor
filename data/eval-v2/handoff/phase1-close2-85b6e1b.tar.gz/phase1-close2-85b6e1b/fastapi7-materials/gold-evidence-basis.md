# fp07 gold 逐项依据（制作侧；provisional，待独立复核）

## locators

| locatorId | 定位 | 依据 |
|---|---|---|
| loc-server-error | log, keyContent="TypeError: Object of type Decimal is not JSON serializable", level=ERROR | server-log-capture.tsv 第 40 行（实测栈尾）；buggy-run-stdout.txt 同文本；该文本仅在故障版本产生 |
| loc-buggy-handler | code, app@cc4c13e4, fastapi/exception_handlers.py L21-22, keyContent="content={\"detail\": exc.errors()}" | 故障版源码实读（git show cc4c13e4:fastapi/exception_handlers.py）；修复 diff 显示同一行被改为 jsonable_encoder(exc.errors()) |

## evidenceRequirements

- req-validation-500（root）：AND 组合 [loc-server-error, loc-buggy-handler]
  依据：仅日志只能证明"序列化异常"，仅代码只能证明"未过 encoder"；两者合取才支持
  "校验错误路径上的序列化缺陷导致 500"这一根因判断（方案 §6.4 支持组合示例同构）。

## requiredFacts

- fact-serialization-error（Decimal+serializable，confirmedFacts/hypotheses）：buggy-run-stdout.txt 栈尾 TypeError 文本
- fact-http-500（500，summary/confirmedFacts）：故障版行为=HTTP 500（TestClient raise_server_exceptions 语义下表现为服务端异常）；修复版同请求=422

## 反证与边界

- "请求非法所以 422 才对"不是根因：故障版对同样请求返回 500 而非 422，差异在服务端处理路径。
- 可接受等价表述："校验错误处理未过 jsonable_encoder，Decimal 不可序列化导致 500"；
  未预列但有效的证据组合走 needs_gold_review 冻结（方案 §6.4），不临时加白名单。

## 复验记录

- 2026-10-02 复验：环境可复用——同 venv（pip freeze md5 1472d2fc5695e75f35263aff3daa45ea），
  故障版 1 failed / 修复版 1 passed（与首跑一致）。
