# FastAPI #7 资格报告（候选期，未正式接纳）

> 状态：`candidate`。锚点已核验（2026-10-01，本机直连 GitHub API / raw）；**本地复现未执行**，
> 因此还没有当轮日志材料，不得作为正式主线 case 运行（方案 §3.3 准入门槛 3/4 未满足）。

## 1. 来源

- 数据集：BugsInPy（`soarsmu/BugsInPy`），项目 fastapi，bug 7。
- 原始 Issue：fastapi/fastapi#743（exotic pydantic 校验错误导致 500）。
- 修复 PR：fastapi/fastapi#748（fix commit `19c77e35`）。

## 2. 版本锚点（已核验）

| 项 | 值 | 核验方式 |
|---|---|---|
| 故障版本 | `cc4c13e4ae3f65fc76c23962b316df4a60e0c7e0`（v0.44.0，2019-11-27） | GitHub Commits API 返回 200，提交元数据匹配 |
| 修复版本 | `19c77e35bdde33aeec1eb2cfa680f95016492b69` | 同上；提交信息 "Fix issue with exotic pydantic error serialization (#748)" |
| 触发测试 | `tests/test_multi_body_errors.py::test_jsonable_encoder_requiring_error` | raw.githubusercontent 在故障 SHA 下返回 200 |
| 环境锁定 | Python 3.8.3（bug.info） | bug.info 抓取 |
| 修复 diff | `fastapi/exception_handlers.py`：`exc.errors()` → `jsonable_encoder(exc.errors())` | GitHub commit diff（Accept: application/vnd.github.diff） |

## 3. 故障机制（制作侧理解，供评分标准使用；不进入 Agent 可见材料）

校验异常处理器直接返回 `exc.errors()`；当模型字段使用 `condecimal(gt=Decimal(0.0))` 时，
错误对象内含不可 JSON 序列化的 Decimal → 服务端 500（TypeError: Object of type Decimal is not
JSON serializable），而契约预期是 422。修复后同一请求返回 422。

- 触发输入：`POST /items/`，body 含 `age` 为受约束 decimal 的非法输入。
- 故障版本行为：HTTP 500 + 服务端异常栈（日志证据所在）。
- 修复版本行为：HTTP 422 + 结构化 validation 错误。
- gold 证据（制作侧）：服务端异常栈日志（含 TypeError 与 exception_handlers.py 位置） +
  故障版本 `exception_handlers.py` 对应行区间（未过 jsonable_encoder 的 content 构造）。

## 4. 复现状态（2026-10-02 更新：复现完成）

- [x] 锚点核验（上表全部完成）
- [x] 历史环境复现：deadsnakes 安装 Python 3.8.20（与 bug.info 标注 3.8.3 为同小线
      patch 差异，已记录）；依赖锁定 `pydantic==0.32.2` + `starlette==0.12.9`（故障版
      pyproject 锚点）+ pytest 5.4.3。环境锁 `repro/env-lock-buggy.txt`。
- [x] 触发器：`tests/test_multi_body_errors.py::test_jsonable_encoder_requiring_error`。
      该测试随修复提交新增——按 BugsInPy 约定取**修复版测试文件**跑**故障版源码**（浅克
      隆仅含故障 SHA，`repro/fastapi-repo`）。
- [x] 双向对照（同一触发、同一环境）：
      - 故障版 `cc4c13e4`：**1 failed** — `TypeError: Object of type Decimal is not JSON
        serializable`（`repro/buggy-run-stdout.txt`）
      - 修复版 `19c77e35`：**1 passed**（`repro/fixed-run-stdout.txt`）
- [x] 服务端异常日志：`repro/server-log-capture.tsv`（42 行 TSV，栈逐行保留原行映射，
      含 `exception_handlers.py line 21` 帧与 TypeError；时间为 `derived_metadata`
      归一化评测时间 2026-09-06T10:01:58+08:00，非原事故时间；采集包装脚本
      `capture_server_log.py` 标 `reconstructed_harness`）。
- [x] 当轮 gold：`private/fp07-clarify/truth.private.json`（log+code 双 locator、
      AND 组合、必需事实），**provisional**（单一 AI 起草，独立人工复核未完成）。
- [x] 隔离：评测仓库 `public/fp07-clarify/repo` 仅含故障提交对象（`git cat-file`
      验证修复 commit 不可达）；case 复用/裁剪映射：故障树 = 上游原始 tree，无派生。

## 4b. 结论

**admission：candidate → qualified。** 复现与材料冻结完成；转 `admitted` 还差：
①独立人工复核 gold（当前 provisional）；②按 §3.3 九条门槛做接纳复核。
未复核前运行该 case 会被 schema 门禁拒绝（blocked.json 记录），这是预期行为。

## 5. 困难与风险

- 老依赖安装是主要成本；若 3.8.3 环境无法就绪，备选：把故障版本包装成最小 FastAPI 服务
  在现代 Python 上复现同一序列化异常——但那属于 `reconstructed_harness` 材料，必须显式标记，
  不能冒充 2019 年原始运行日志。
- 公开 Issue 存在被模型训练数据覆盖的可能；manifest 已标 `publicBenchmark: true`，分数解释
  时注明可能污染，不宣称无偏泛化。

## 6. 接纳判断

保持 `candidate`。补齐复现与材料后按 §3.3 九条门槛复核，通过才写入 catalog 并标 `admitted`。

## 7. 环境复验（2026-10-02）

- 同 venv（`pip freeze` md5 `1472d2fc5695e75f35263aff3daa45ea`）重跑双向触发：
  故障版 cc4c13e4（修复版测试文件）→ **1 failed**；修复版 19c77e35 → **1 passed**。与首跑一致。
- 结论：**服务器历史环境仍可复用**，无需重建；依赖锁定文件 env-lock-buggy.txt 有效。
- 新增资料：REBUILD.md（完整重建命令）、admission-checklist.md（九项准入表）、
  private/fp07-clarify/gold-evidence-basis.md（gold 逐项依据）。admission 维持 qualified。
