# FastAPI 7 九项准入门槛核对（方案 §3.3）——状态：qualified，未 admitted

| # | 门槛 | 状态 | 依据 |
|---|---|---|---|
| 1 | 现象可描述 | ✅ | r1-message.txt：输入/实际(500)/预期(422)/时间均明示 |
| 2 | 来源可查 | ✅ | BugsInPy fastapi#7；原 Issue fastapi#743；PR #748；许可边界=只引用不打包上游代码（评测仓库为浅克隆，不入主仓库） |
| 3 | 版本可核验 | ✅ | 故障 SHA cc4c13e4 完整解析；TSV 日志与该版本对应关系见 gold-evidence-basis.md |
| 4 | 材料真实或明确重建 | ✅ | pytest 双版本原始输出为真实运行；server TSV 标 derived_metadata；包装脚本标 reconstructed_harness |
| 5 | 当轮标准可判 | ✅ | truth 含 requiredFacts（Decimal/500）+ evidenceRequirements（log+code AND 组合）；非"唯一答案字符串" |
| 6 | 能力相匹配 | ✅ | 所需信号=异常栈日志+源码 handler 行——当前 query_logs/read_code 均可取得 |
| 7 | 预算可接受 | ✅ | 单轮、材料 <1MB、无 trace/指标依赖 |
| 8 | 答案可隔离 | ✅ | 评测仓库仅含故障提交（修复对象 cat-file 不可达）；truth/private 不在任何工具范围；预检已验证 |
| 9 | 标准经过复核 | ❌ 待办 | gold 由单一 AI 起草（provisional）；**独立人工复核未完成——这是 admitted 的唯一阻塞项** |

结论：1–8 具备；9 待独立复核。复核通过 → 生成 review 工件 → admission=admitted。
