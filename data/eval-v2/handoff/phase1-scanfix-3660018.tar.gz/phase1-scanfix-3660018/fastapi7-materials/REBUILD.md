# FastAPI 7 完整重建命令（制作侧；全部命令已在服务器实跑验证）

> 基线：本文件描述的流程于 2026-10-01 首跑、2026-10-02 复验通过。
> 触发测试随修复提交新增——按 BugsInPy 约定：**故障版源码 + 修复版测试文件**。

## 1. 环境准备

```bash
# Python 3.8（bug.info 标 3.8.3；服务器用 deadsnakes 3.8.20，同小线 patch 差异已记录）
sudo add-apt-repository -y ppa:deadsnakes/ppa
sudo apt-get install -y python3.8 python3.8-venv python3.8-distutils
python3.8 -m venv venv-buggy
venv-buggy/bin/pip install -q "pydantic==0.32.2" "starlette==0.12.9" "pytest==5.4.3" "requests"
# 依赖锚点来自故障版 pyproject.toml：starlette >=0.12.9,<=0.12.9；pydantic >=0.32.2,<2.0.0
venv-buggy/bin/pip freeze > env-lock-buggy.txt
```

## 2. 故障版仓库（浅克隆单提交）

```bash
git init fastapi-repo && cd fastapi-repo
git remote add origin https://github.com/fastapi/fastapi.git
git fetch -q --depth 1 origin cc4c13e4ae3f65fc76c23962b316df4a60e0c7e0
# 制作侧同时取修复提交（对照运行需要）；评测用仓库只含故障提交，见 §10.1 隔离要求
git fetch -q --depth 1 origin 19c77e35bdde33aeec1eb2cfa680f95016492b69
git checkout -q -b main FETCH_HEAD   # HEAD = cc4c13e4（v0.44.0，2019-11-27）
```

## 3. 触发（故障版：预期 1 failed）

```bash
# 触发测试取自修复提交（BugsInPy 约定）
git show 19c77e35bdde33aeec1eb2cfa680f95016492b69:tests/test_multi_body_errors.py > tests/test_multi_body_errors.py
../venv-buggy/bin/python -m pytest "tests/test_multi_body_errors.py::test_jsonable_encoder_requiring_error"
# 预期输出（已实测三次，含 2026-10-02 复验）：1 failed —
#   TypeError: Object of type Decimal is not JSON serializable
```

## 4. 修复版对照（同一触发、同一 venv）

```bash
git checkout -q -- tests/test_multi_body_errors.py   # 先还原本地改动，否则 checkout 被拒
git checkout -q 19c77e35bdde33aeec1eb2cfa680f95016492b69
../venv-buggy/bin/python -m pytest "tests/test_multi_body_errors.py::test_jsonable_encoder_requiring_error"
# 预期输出（已实测两次）：1 passed
```

## 5. 服务端异常日志采集（reconstructed_harness）

```bash
git checkout -q cc4c13e4ae3f65fc76c23962b316df4a60e0c7e0
git show 19c77e35bdde33aeec1eb2cfa680f95016492b69:tests/test_multi_body_errors.py > tests/test_multi_body_errors.py
../venv-buggy/bin/python ../capture_server_log.py
# 产出 server-log-capture.tsv（42 行，栈逐行保留；时间为 derived_metadata）
# capture_server_log.py 用 TestClient 复现与 uvicorn/ServerErrorMiddleware 同一异常对象；
# 请求体来源 = 修复版测试文件的用例体（PUT /items/1，age=0.0 触发 condecimal 校验错误）
```

## 5b. 同请求原始响应对照（故障版 vs 修复版）

```bash
# 同一 PUT 请求（与触发测试同源），raise_server_exceptions=False 采集原始 HTTP 响应：
git checkout -q cc4c13e4ae3f65fc76c23962b316df4a60e0c7e0
../venv-buggy/bin/python ../capture_raw_responses.py ../fastapi-repo buggy  > response-buggy.txt
git checkout -q 19c77e35bdde33aeec1eb2cfa680f95016492b69
../venv-buggy/bin/python ../capture_raw_responses.py ../fastapi-repo fixed  > response-fixed.txt
# 实测：buggy = HTTP 500（Internal Server Error）；fixed = HTTP 422（结构化校验错误）
```

## 5c. 两类请求的来源区分（不得混同）

| 请求 | 用途 | 来源 | 标记 |
|---|---|---|---|
| pytest 触发（test_jsonable_encoder_requiring_error） | 历史回归触发器，产 pytest 失败/通过输出（buggy-run-stdout.txt / fixed-run-stdout.txt） | BugsInPy run_test.sh + 修复版测试文件 | 历史复现证据 |
| HTTP PUT /items/1（capture_raw_responses.py） | 采集原始请求/响应对照（response-*.txt） | 与触发测试同源的请求体（修复版测试文件用例体） | reconstructed_harness |
| HTTP PUT /items/1（capture_server_log.py） | 采集服务端异常栈（server-log-capture.tsv） | 同上 | reconstructed_harness + derived_metadata 时间 |

## 6. 已知偏差（不得隐瞒）

| 项 | bug.info / 原始 | 本服务器 | 判断 |
|---|---|---|---|
| Python | 3.8.3 | 3.8.20（deadsnakes） | 同小线 patch 差异；故障路径为 JSON 编码器行为，3.8.x 内无差异，已记录待人工归因确认 |
| pytest | 未锁（BugsInPy run_test.sh 仅 pytest） | 5.4.3（2019 时代版本） | 触发语义无影响 |
| 触发测试文件 | BugsInPy 流程自带 | 取自修复提交 19c77e35 | 与 BugsInPy patch.sh 语义一致 |
