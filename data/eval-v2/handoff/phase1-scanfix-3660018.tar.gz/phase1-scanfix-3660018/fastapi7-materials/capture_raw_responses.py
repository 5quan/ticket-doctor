# 同一 PUT 请求在故障版/修复版上的原始 HTTP 响应对照采集（reconstructed_harness）。
# 用法：venv-buggy/bin/python capture_raw_responses.py <fastapi-repo-dir> <buggy|fixed>
# 请求体来源 = 修复版测试文件的用例体（与触发测试同源）。
import json
import sys
from decimal import Decimal

repo_dir, run_label = sys.argv[1], sys.argv[2]
sys.path.insert(0, repo_dir)

from fastapi import FastAPI  # noqa: E402
from pydantic import BaseModel, condecimal  # noqa: E402
from starlette.testclient import TestClient  # noqa: E402

app = FastAPI()


class Item(BaseModel):
    name: str
    age: condecimal(gt=Decimal(0.0))


class User(BaseModel):
    username: str


@app.put("/items/{item_id}")
def update_item(*, item_id: int, item: Item, user: User):
    return {"item_id": item_id, "item": item, "user": user}


client = TestClient(app, raise_server_exceptions=False)
body = {"item_id": "1", "item": {"name": "foo", "age": "0.0"}, "user": {"username": "bar"}}
resp = client.put("/items/1", json=body)

out = (
    f"run: {run_label}\n"
    f"request: PUT /items/1 json={json.dumps(body, ensure_ascii=False)}\n"
    f"status: {resp.status_code}\n"
    f"headers: {dict(resp.headers)}\n"
    f"body:\n{resp.text}\n"
)
with open(f"response-{run_label}.txt", "w") as f:
    f.write(out)
print(out)
