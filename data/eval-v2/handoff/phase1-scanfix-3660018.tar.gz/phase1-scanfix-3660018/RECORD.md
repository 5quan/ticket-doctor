# 同一提交集中运行记录（commit 3660018）

环境：Linux（Ubuntu 24.04 / Node v22.23.2）。

| 项 | 结果 | 明细 |
|---|---|---|
| 全量测试 | 通过 | 196 = 195 通过 + 1 跳过 + 0 失败 |
| 跳过（1） | 环境限制 | Windows junction 用例（非 Windows skip） |
| 失败（0） | — | 无；无超时类失败 |
| scripted suite | 完成 | phase1-scanfix-3660018：5 trial（3 行为全绿 + 2 版本 case 预期阻断 execution_error）；附 0e0e7d8 中间运行（计数回填前）留档 |
| replay | 一致 | 5/5 逐字段一致 |
| typecheck / docs:check | 通过 | 0 错误 / tests.ts=196 |

本批新增反例：视图子目录枚举失败 → incomplete_scan；私有目录内目录链接 → private_link；
（Linux 环境；Windows junction 支持暂缓，未验证——正式评测环境为 Linux 服务器。）

FastAPI 7 新增材料：REBUILD 占位符修复 + 修复提交获取步骤；同 PUT 请求双版本原始响应对照
（response-buggy.txt=500 / response-fixed.txt=422）；请求来源三分映射表。admission 维持 qualified。
