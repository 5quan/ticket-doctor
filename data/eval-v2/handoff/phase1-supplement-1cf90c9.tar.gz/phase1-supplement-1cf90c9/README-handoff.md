# 阶段一补充收尾交接包（基准 1cf90c9，Linux 服务器实跑）

## 与上一包的关系（对应依据）
- 上一包 phase1-d270c0a.tar.gz（含其 .sha256）随包附带，链路连续。
- 本批实现当前**未提交**：`impl-diff/uncommitted-impl.patch` 可直接应用于 1cf90c9
  （`git apply uncommitted-impl.patch`）复现服务器工作区；`git-status.txt`/`git-log-head.txt`
  为当时工作区与提交链快照。impl-diff 内的文件与将来提交的对应关系：
  - src/sources/logs.ts（realpath+空授权）与 src/config/index.ts、src/diagnosis/orchestrator.ts
    （onPrepared 观察钩）→ 生产配套提交
  - src/evals/v2/*、tests/*、docs/* → 评测修复提交（与 d270c0a/1cf90c9 两笔既有提交同风格拆分）

## 内容
- runs/phase1-final-1/  本批验收运行（scripted，5 工程 trial；2 个版本 trial 为预期阻断）
- runs/phase1-final-2/  fake 引擎交叉运行：eng-clarify r1 无授权服务被**运行期拒绝**（空授权语义的实证）
- impl-diff/            未提交实现与 1cf90c9 的对应依据（patch/stat/status/log）
- verification/         typecheck / 全量 TAP / docs:check 原始输出 + 环境信息
- 上一包中的 FastAPI 7 资格资料未变化（admission=qualified），不重复附带；见 phase1-d270c0a 包

## 本批新增语义（对应工单 §1–§3）
- 视图两两关系：相等 + 两个方向的父子包含（真实路径）→ path_overlap
- 跨轮硬链接：inode 重合 → hardlink_escape（运行期路径规则发现不了，回归测试先证明缺口存在）
- 扫描完整性与未来消息检查分离：每轮（单轮/末轮）对视图与仓库树（expectedSha+HEAD 双树）扫描，
  超限/失败 → incomplete_scan，不判隔离通过
- 读取前核对覆盖全部期望仓库：missing-in-scope / unresolved / mismatch 都阻断；
  正式 case 缺 expectedSha 由 schema 拒绝；工程场景缺期望仍核对实际可读版本（no-expected）

## 结果口径
- 全量测试 189 = 188 通过 + 1 跳过（Windows junction，非 Windows 环境）+ 0 失败；无超时类失败
- eng-version-drift/headfix 的 executionSuccess=false 为预期阻断；trace 无任何取证事件
- private 资料仅供监督方；资料同步不代表 fp07 准入通过
