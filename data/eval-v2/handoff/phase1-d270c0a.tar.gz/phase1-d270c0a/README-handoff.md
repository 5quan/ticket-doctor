# 阶段一交接包（基准 d270c0a，Linux 服务器实跑）

## 内容
- runs/phase1-verify-1/    本批验收运行（5 工程 case：3 行为 + 2 版本阻断），含 trace/outputs/score/summary/manifest/replay
- runs/audit-verify-1/     上一轮（评分修复）验收运行，原样保留
- candidates/              FastAPI 7/12/5 候选资格记录（fastapi-7=qualified）
- fastapi7-repro/          复现证据：故障/修复版 pytest 原始输出、服务端异常 TSV（derived 时间）、采集脚本、依赖锁、fp07 case+truth
- verification/            Linux 环境 typecheck / 全量测试 TAP / docs:check 原始输出 + 环境信息

## 未包含（体积原因）与重建命令
- fastapi7-repro 不含 fastapi 源码仓库与 venv。重建：
  git init fastapi-repo && cd fastapi-repo && git remote add origin https://github.com/fastapi/fastapi.git
  git fetch --depth 1 origin cc4c13e4ae3f65fc76c23962b316df4a60e0c7e0 && git checkout -q FETCH_HEAD
  python3.8 -m venv venv && venv/bin/pip install pydantic==0.32.2 starlette==0.12.9 pytest==5.4.3 requests
  venv/bin/python -m pytest tests/test_multi_body_errors.py::test_jsonable_encoder_requiring_error   # 故障版：1 failed
- fp07 评测仓库（仅故障提交，修复对象不可达）在 data/eval-v2/public/fp07-clarify/repo，未打包；可用上述故障 SHA 重建。

## 结果口径（区分环境/失败/跳过/超时）
- 本包全部结果产生于 Linux（见 verification/environment.txt）。
- 全量测试：184 用例 = 183 通过 + 1 跳过（Windows junction 用例，非 Windows skip）+ 0 失败；无超时类失败。
- eng-version-drift / eng-version-headfix 两 trial 的 executionSuccess=false 是**预期阻断**（读取前版本核验），
  不是 harness 故障；trace 中无任何取证事件可证。
- private/fp07-clarify 为制作侧答案，仅供监督方使用；资料同步不代表 fp07 准入通过（仍为 qualified，待独立复核）。
