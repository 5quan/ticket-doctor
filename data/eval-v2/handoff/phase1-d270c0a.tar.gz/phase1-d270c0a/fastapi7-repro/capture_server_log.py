# 按 BugsInPy 触发测试的应用形态（修复版测试文件同源）发起同一非法请求，
# 捕获服务端异常栈（与 uvicorn/ServerErrorMiddleware 记录同一异常对象），逐行写 TSV。
# 本脚本属 reconstructed_harness：请求采集方式是重建的，异常本身来自真实历史代码路径。
import sys, traceback
from decimal import Decimal
from typing import List

sys.path.insert(0, "fastapi-repo")
from fastapi import FastAPI
from pydantic import BaseModel, condecimal
from starlette.testclient import TestClient

app = FastAPI()

class Item(BaseModel):
    name: str
    age: condecimal(gt=Decimal(0.0))

class User(BaseModel):
    username: str

@app.put("/items/{item_id}")
def update_item(*, item_id: int, item: Item, user: User):
    return {"item_id": item_id, "item": item, "user": user}

client = TestClient(app)
body = {"item_id": "1", "item": {"name": "foo", "age": "0.0"}, "user": {"username": "bar"}}
resp = None
try:
    resp = client.put("/items/1", json=body)
except Exception:
    tb = traceback.format_exc()
    status = "server-exception (raise_server_exceptions=True)"
print("HTTP status:", resp.status_code if resp else status, file=sys.stderr)
print("body:", resp.text if resp else "(exception raised)", file=sys.stderr)

TSV = "server-log-capture.tsv"
DERIVED_TIME = "2026-09-06T10:01:58.312+08:00"  # derived_metadata：归一化评测时间，非原事故时间
lines = [f"{DERIVED_TIME}\tERROR\t{line}" for line in tb.splitlines()]
with open(TSV, "w") as f:
    f.write("\n".join(lines) + "\n")
print(f"wrote {TSV}: {len(lines)} lines", file=sys.stderr)
