# fp07 制作侧根因（非 Agent 可见）

request_validation_exception_handler 直接返回 exc.errors()（fastapi/exception_handlers.py L21-22）。
condecimal 校验错误对象内含 Decimal，不可 JSON 序列化 → 服务端 500（TypeError: Object of type
Decimal is not JSON serializable）。修复版（19c77e35）改为 jsonable_encoder(exc.errors()) → 422。
预期业务行为：422（校验失败），实际 500（服务端缺陷）。
等价替代证据组合可经 needs_gold_review 冻结（方案 §6.4），不得临时加白名单。
