# 阶段一收尾二交接包（提交 520d7aa，Linux 服务器实跑）

## 内容
- runs/phase1-close-1/      本批验收运行（5 工程 trial：3 行为全绿 + 2 版本 case 预期阻断 execution_error）
- impl-diff/PROVENANCE.md   提交与产物对应关系（f9560a0/520d7aa ↔ 各交接包），工作区已干净
- verification/             typecheck / 全量 TAP / docs:check 原始输出 + 环境信息
- 附带此前两包 tar 与 .sha256（链路完整）

## 结果口径
- 全量测试 191 = 189 通过 + 1 跳过（Windows junction，非 Windows 环境）+ 0 失败；无超时类失败
- 本批新增反例（摘要）：私有答案硬链接（预检 inode 阻断）、
  中间提交含答案文件/未来文本（解析树扫描取证前阻断）、缺席仓库、无期望场景核对
- private/* 为制作侧答案，仅供监督方；资料同步不代表 fp07 准入通过
