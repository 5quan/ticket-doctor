# 提交与产物对应关系（本包生成于 520d7aa，工作区干净）

| 提交 | 内容 | 对应产物 |
|---|---|---|
| f9560a0 | 阶段一补充收尾（视图包含双向/hardlink/版本核对矩阵/扫描完整性分离） | phase1-supplement-1cf90c9.tar.gz 内 impl-diff/uncommitted-impl.patch 即该提交的提交前快照（827 行 diff，内容一致） |
| 520d7aa | 阶段一收尾二（私有材料硬链接、解析树读取前隔离扫描、夹具修正） | 本包 runs/phase1-close-1 全部 trace/score；工作区已干净（无未提交实现） |
| 0b9ba1a | 交接包入库存档 | 包内附带的两份早期 tar 及 .sha256 |

本包生成时 `git status --porcelain` 为空——不存在未提交实现；后续实现进入阶段二。
